import processing.core.*; import processing.opengl.*; import java.applet.*; import java.awt.*; import java.awt.image.*; import java.awt.event.*; import java.io.*; import java.net.*; import java.text.*; import java.util.*; import java.util.zip.*; import javax.sound.midi.*; import javax.sound.midi.spi.*; import javax.sound.sampled.*; import javax.sound.sampled.spi.*; import java.util.regex.*; import javax.xml.parsers.*; import javax.xml.transform.*; import javax.xml.transform.dom.*; import javax.xml.transform.sax.*; import javax.xml.transform.stream.*; import org.xml.sax.*; import org.xml.sax.ext.*; import org.xml.sax.helpers.*; public class BoidCamArty_Object_00 extends PApplet { // commented out for online use only


// controls:
// spacebar: turn mouse on/off
// o: turn obstacles on/off
// b: turn walls on/off

// ************************* DRAWING VARIABLES **************************  


final int FRAME_RATE = 500;

final int NUM_BOIDS              = 200;
final int NUM_OBSTACLES          = 500;
final int NUM_PREDATORS          = 0;//10;//75;
final int CENTER_PULL_FACTOR     = 1200;
final int TARGET_PULL_FACTOR     = 800;
final int FOOD_PULL_FACTOR       = 100;
final int OBSTACLE_DISTANCE      = 30;
final int PREDATOR_DISTANCE      = 18;
final int FOOD_DISTANCE          = 20;
final float BOUNCE_ABSORPTION    = 2.25f; // initially .25
final int VELOCITY_PULL_FACTOR   = 100;
final int MIN_DISTANCE = 18;
final float VELOCITY_LIMITER = 16.0f  ;
//final float MAX_DISTANCE = sqrt(CAVE_WIDTH*CAVE_WIDTH+CAVE_HEIGHT*CAVE_HEIGHT); //TODO:
final float MAX_DISTANCE = sqrt(1500*1500+15000*1500);

// new damping variables.
float r1Damping = 1.0f;
float r2Damping = .2f;
float r3Damping = 1.0f;
float r4Damping = 0.0f;
float r5Damping = 1.0f;
float r6Damping = 1.0f;

float xRot = 0;
float yRot = 0;

boolean showObstacles = true;
boolean bounceFromWalls = true;

PImage _boidImage;
PFont font;


Boid[]       flock      = new Boid[NUM_BOIDS];
Obstacle[]   obstacles  = new Obstacle[NUM_OBSTACLES+NUM_PREDATORS];
ArrayList    foods      = new ArrayList();

// Objects..
Background _background = new Background();
World      _world;




public void setup()  
{
   //size(500, 500);  // for the browser only... take the other one for offline use
   size(1280, 920, OPENGL);    
   rectMode(CENTER);
   
   //_boidImage = loadImage("BoidCamArty-1372.tif");
   font = createFont("Courier", 12);

   initializeEntities();
   
   initializeRenderers();
   
   frameRate(FRAME_RATE);
   hint(ENABLE_OPENGL_4X_SMOOTH) ;
   
}

public void initializeRenderers()
{
   //_background.setRenderer(new SaturatedBackgroundRenderer());   
   _background.setRenderer(new NoiseGreyScaleBackgroundRenderer());
   
   _world.setRenderer(new WorldRenderer());
   
}




public void initializeEntities()
{
   
   _world = new World(1500,1500,1500);
     
   
   for(int i=0; i<NUM_BOIDS; i++)
   {
      flock[i] = new Boid();
      if (i % 2 ==0)
         flock[i].setRenderer(new BoidRenderer());
      else
         flock[i].setRenderer(new BoidGreyRenderer());

   } // end for


   for (int i=0; i<NUM_OBSTACLES; i++) {
      obstacles[i] = new Obstacle();
   }

   for (int i=0; i<NUM_PREDATORS; i++) {
      obstacles[NUM_OBSTACLES+i] = new Predator();
   }

}




float counter=0;

//color from,to, bg;

public void draw()  
{

   


   
   
   
   //println((int)flock[0].xpos + ";" +  (int)flock[0].zpos + ";" +  (int)flock[0].zpos);

   _background.render();
   _world.render();

   
   
     colorMode(HSB);
    //background((millis()/1000)*200 ,255,255);
    
   
    
    //println(sin(frameCount));
    println(counter);

   
   
  
  /*
  hint(DISABLE_DEPTH_TEST);
  
  beginShape();
    fill(30,30,80);
    vertex(0,0);
    vertex(width, 0);
    fill(0,0,20);
    vertex(width, height);
    vertex(0, height);
  endShape(CLOSE);
  
   fill(150);  
   textFont(font);
   text("FPS: " + int(frameRate), 10, height-12);
  
    
    unhint(DISABLE_DEPTH_TEST); 
    
   */ 
    
   

   
   lights();

   translate(width/2,height/2,-300);
   //rotateY(xRot);
   //rotateX(yRot);
   
   /*
   rotateX(TWO_PI/height*mouseY);
   rotateY(TWO_PI/width*mouseX);
   */


   

   //beginCamera();
   //camera(flock[0].xpos, flock[0].zpos, flock[0].zpos, CAVE_HEIGHT/2,CAVE_HEIGHT/2,CAVE_HEIGHT/2, 0,noise(-1.0,1.0),noise(-1.0,1.0));
   camera(flock[0].xpos-150, flock[0].ypos-150, flock[0].zpos-500, 
   flock[10].xpos, flock[10].ypos, flock[10].zpos, 
   1,1,1);
   /*
   camera(0,0,-500+frameCount, 
   750, 750,750,
   1,1,1);
   */
   /*
   camera(750,750,750, 
   flock[10].xpos, flock[10].ypos, flock[10].zpos, 
   1,1,1);
   */
   
   //endCamera();

   
   



   //pointLight(50, 55, 45, flock[30].xpos, flock[30].zpos, flock[30].zpos);   
   //pointLight(noise(random(255))*255, noise(flock[0].xpos)*255, 255, flock[0].xpos, flock[0].zpos, flock[0].zpos);
   //pointLight(110, 110, 110, flock[0].xpos, flock[0].zpos, flock[0].zpos);


   for (int i=0; i<NUM_BOIDS; ++i)
   {
      

      // let's not see the camera-pointed entity (it's always in the center of the screen).
      if (i== 9)
         continue;
       
      if (frameCount %150 ==0)
      {

         //flock[i].setRenderer(new NetworkBoidRenderer());
      }   
      flock[i].drawMe();
    // end for
   }



   if (showObstacles) {
      for (int i=0; i<obstacles.length; i++) {
         obstacles[i].draw(); 
      }
   }

   for (int i=0; i< foods.size(); i++) {
      ((Food)foods.get(i)).draw();
   }
   
   


   
   

}


public void mousePressed() {

   foods.add(new Food(PApplet.parseInt(random(0, _world.x)), PApplet.parseInt(random(0,_world.y)), PApplet.parseInt(random(0,_world.z))));

}

public void keyPressed() {

   // switch mouse attraction on/off
   /*
  if (key== ' ' ) {
    if (r4Damping==0.0) {
    println("mouse on");
    r4Damping = 1.0;
    } 
    else {
    println("mouse off");
    r4Damping = 0.0; 
    }
    } 
    else */   if (key == 'o') {
      if (!showObstacles) {
         println("obstacles on");
         showObstacles = true;
         r5Damping = 1.0f;
      } 
      else {
         println("obstacles off");
         showObstacles = false;
         r5Damping = 0.0f; 
      }
   } /*
  else if (key == 'b') {
    if (!bounceFromWalls) {
    println("walls on");
    bounceFromWalls = true;
    } 
    else {
    println("walls off");
    bounceFromWalls = false;
    }
    } */
   else if (keyCode == UP) {
      yRot += .1f;
   }  
   else if (keyCode == DOWN) {
      yRot -=.1f;
   }
   else if (keyCode == RIGHT) {
      xRot += .1f;
   }    
   else if (key == 'f')    // new food at camera-holding boid position..
   {
      foods.add(new Food((int)flock[0].xpos, (int)flock[0].zpos, (int)flock[0].zpos));
      ;
   }  

   else if (key == 'r')   // new food at random position..
   {
      foods.add(new Food(PApplet.parseInt(random(0,_world.x)), PApplet.parseInt(random(0,_world.y)), PApplet.parseInt(random(0,_world.z))));  
   }  

   else if (key == 's') {
      saveFrame("BoidCamArty-####.tif");      
   }  


}


// -> extrapixel  : http://processing.org/discourse/yabb_beta/YaBB.cgi?board=Syntax;action=display;num=1193175897;start=1#1


public class Background implements IRenderable
{
   public IRenderer _renderer;
   
   public void setRenderer(IRenderer renderer)
   {
      _renderer = renderer;
   }
   
   public void render()
   {
      _renderer.render( this );
   }
}

/**
* Boid class.
*
*
*/
public class Boid implements IRenderable
{
   final int TRAIL_SCALE = 8;

   Vector3 v1 = new Vector3();
   Vector3 v2 = new Vector3();
   Vector3 v3 = new Vector3();
   Vector3 v4 = new Vector3();
   Vector3 v5 = new Vector3();
   Vector3 v6 = new Vector3();

   int myColor = color(255, 255, 255,80);
   int mySize = 4;

   public float xpos, ypos, zpos;
   float tailXpos, tailYpos, tailZpos;
   float tailXwant, tailYwant, tailZwant;
   float tailXpos2, tailYpos2, tailZpos2;
   
   float vx, vy, vz; // direction..
   
   IRenderer _renderer;
   
   public IRenderer getRenderer()
   {
      return _renderer;
   }


   public Boid() 
   {
      xpos = width/2+random(-200, 200);
      ypos = height/2+random(-200, 200);
      zpos = height/2+random(-200, 200);

      tailXpos = xpos;
      tailYpos = ypos;
      tailZpos = zpos;

      vx = random(-.5f, .5f);
      vy = random(-.5f, .5f);
      vz = random(-.5f, .5f);

      updateTail();
   }

   public void drawMe()
   {
      updateBoid();
      
      //drawTail();

      
      pushMatrix();
      
         translate(xpos,ypos,zpos);
         noStroke();
         _renderer.render( this );
         //render();
         //render_transparency();
            
      popMatrix();
   }

   /**
   * Renders the Boid..
   *
   */
   public void render()
   {
      //int _blue = (int)(xpos/1500)*255-100;
      //strokeWeight(mySize*10);
      //stroke(0,5);
      int _blue = ((int)(xpos/1500))*255-100;
      colorMode(HSB);
      for (int cubes = 1; cubes < 4; cubes ++)
      {  
         //rotate(radians(noise(10,70)*110)); 
         //fill(cubes*20,255, 100,255 - (cubes * 63.75));
         fill(noise(frameRate)* noise(10,50),10);
         box(mySize * (cubes * 2.35f));
      }
      colorMode(RGB);
      
      /*
      int i=0;      
      sphereDetail(10);      
      texture( _boidImage );
      sphere(mySize*3.5);
      i++;
      */      
   }


   
   public void setRenderer(IRenderer renderer)
   {
      _renderer = renderer;      
   }
   
   
   

   /**
   * Renders the Boid..
   *
   */
   public void render_01()
   {
      pushMatrix();
      //println(noise(xpos));
      //scale((xpos+ypos+zpos/3500)*noise(0.0025)*0.0038);
      rotateX(1.001f);
      fill(10,(ypos/1000)*255,(xpos/1000)*255,255);
      noStroke();
      box(mySize);
      //box(mySize*sqrt(vx*vx+vy*vy));
      //image( _boidImage, 0, 0, mySize * 5, mySize * 5);
      popMatrix();
   }


   public void render_transparency()
   {
      noStroke();
      //colorMode(HSB);
      //println((int)xpos + ";"+ (int)ypos+";"+ (int)zpos + ";");

      fill((ypos/1000)*255,(ypos/1000)*255,255,255);
      box(mySize);

      // Transparency..
      for (int s = mySize, iter=0; s < 15; s+=3, iter++)
      {
         fill((ypos/1000)*255,(ypos/1000)*255,(zpos/1000)*200,255 - (55*iter));
         box(s);
      }
   }

 /**
   * Draws the standard line tail.
   */
   public void drawTail()
   {
      updateTail();

      stroke(255,190);
      strokeWeight(.9f);
      /*
       stroke(255,frameRate/10+100);
       strokeWeight(noise(xpos)*10);    
       */
      line(tailXpos, tailYpos, tailZpos, tailXpos2, tailYpos2, tailZpos2);  
      //line(xpos, ypos, zpos, xpos-TRAIL_SCALE*vx, ypos-TRAIL_SCALE*vy, zpos-TRAIL_SCALE*vz);  
      //line(xpos, ypos, zpos, tailXpos2, tailYpos2, tailZpos2); 

      noStroke();
   }









   public void updateTail() 
   {
      tailXwant = xpos-TRAIL_SCALE*vx;
      tailYwant = ypos-TRAIL_SCALE*vy;
      tailZwant = zpos-TRAIL_SCALE*vz;

      tailXpos2 = xpos;
      tailYpos2 = ypos;
      tailZpos2 = zpos;
      tailXpos = tailXpos + (tailXwant - tailXpos)*0.1f;
      tailYpos = tailYpos + (tailYwant - tailYpos)*0.1f;
      tailZpos = tailZpos + (tailZwant - tailZpos)*0.1f;

   }

   public void updateBoid()
   {
      
      rule1();
      rule2();
      rule3();
      
      rule4();
      rule5();
      rule6();
      

      // add Vector3s to velocities
      vx += r1Damping*v1.x + r2Damping*v2.x + r3Damping*v3.x + r4Damping*v4.x + r5Damping*v5.x + r6Damping*v6.x;
      vy += r1Damping*v1.y + r2Damping*v2.y + r3Damping*v3.y + r4Damping*v4.y+ r5Damping*v5.y+ r6Damping*v6.y;
      vz += r1Damping*v1.z + r2Damping*v2.z + r3Damping*v3.z + r4Damping*v4.z+ r5Damping*v5.z+ r6Damping*v6.z;


      if (bounceFromWalls) {
         if (xpos + vx < 0 || xpos + vx > _world.x)
            vx = -vx*BOUNCE_ABSORPTION;

         if (ypos + vy < 0 || ypos + vy > _world.y)
            vy = -vy*BOUNCE_ABSORPTION;
         if (zpos + vz < 0 || zpos + vz > _world.z)
            vz = -vz*BOUNCE_ABSORPTION;
      } 
      else {

         if (xpos + vx < 0 ) {
            xpos = width; 
         } 
         else if ( xpos + vx > _world.x) {
            xpos = 0; 
         }
      }

      limitVelocity();

      if (ypos + vy < 0) {
         ypos = height;     
      } 
      else if (ypos + vy > _world.z) {
         ypos = 0;
      }


      // update new position with previously calculated velocities
      xpos += vx;
      ypos += vy;
      zpos += vz;

   }

   public void limitVelocity()
   {
      float vlim = VELOCITY_LIMITER;

      //float velocity = sqrt(sq(vx) + sq(vy));
      float velocity = dist(0,0,0, vx, vy, vz);

      if (velocity > vlim)
      {
         vx = (vx/velocity)*vlim;
         vy = (vy/velocity)*vlim;
         vz = (vz/velocity)*vlim;
      }  

   } // end limitVelocity()


   // pull to the center
   public void rule1()
   {

      v1.setXYZ(0,0, 0);

      for (int i=0; i < NUM_BOIDS; ++i)
      {
         if (this != flock[i])
         {
            v1.x += flock[i].xpos;
            v1.y += flock[i].ypos;
            v1.z += flock[i].zpos;
         } // end if
      } // end for

      v1.x /= (NUM_BOIDS-1);
      v1.y /= (NUM_BOIDS-1);
      v1.z /= (NUM_BOIDS-1);

      v1.x = (v1.x - xpos) / CENTER_PULL_FACTOR;
      v1.y = (v1.y - ypos) / CENTER_PULL_FACTOR;
      v1.z = (v1.z - zpos) / CENTER_PULL_FACTOR;

   } // end rule1()


   // avoid collision
   public void rule2()
   {

      v2.setXYZ(0,0, 0);
      for (int i=0; i < NUM_BOIDS; ++i)
      {
         if (this != flock[i])
         {
            //if (distance2d(b, flock[i]) < 20)
            if (dist(xpos, ypos, zpos, flock[i].xpos, flock[i].ypos, flock[i].zpos) < MIN_DISTANCE)
            {
               v2.x -= flock[i].xpos - xpos;
               v2.y -= flock[i].ypos - ypos;
               v2.z -= flock[i].zpos - zpos;
            } // end if
         } // end if
      } // end for

   } // end rule2()


   // head to flock average
   public void rule3()
   {

      v3.setXYZ(0,0,0);

      for (int i=0; i < NUM_BOIDS; ++i)
      {
         if (this != flock[i])
         {
            v3.x +=  flock[i].vx;
            v3.y +=  flock[i].vy;
            v3.z +=  flock[i].vz;
         } // end if
      } // end for

      v3.x /= (NUM_BOIDS - 1);
      v3.y /= (NUM_BOIDS - 1);
      v3.z /= (NUM_BOIDS - 1);

      v3.x = (v3.x - vx)/VELOCITY_PULL_FACTOR; //8
      v3.y = (v3.y - vy)/VELOCITY_PULL_FACTOR; //8
      v3.z = (v3.z - vz)/VELOCITY_PULL_FACTOR; //8
   } // end rule3()

   // head the mouse
   public void rule4()
   {
      //v4.setXY(0,0);
      v4.x = (mouseX - xpos) / TARGET_PULL_FACTOR;
      v4.y = (mouseY - ypos) / TARGET_PULL_FACTOR;
      v4.z = (0 - zpos) / TARGET_PULL_FACTOR;

      //stroke(255, 50);
      //line(xpos+v4.x, ypos+v4.y, mouseX, mouseY);
   } // end rule4()





   // obstacle avoidance
   public void rule5() {
      v5.setXYZ(0,0,0);
      for (int i=0; i < obstacles.length; ++i)
      {

         float distance = dist(xpos, ypos, zpos, obstacles[i].x, obstacles[i].y, obstacles[i].z);

         if (distance < obstacles[i].minDistance)
         {
            v5.x -= (obstacles[i].x - xpos);
            v5.y -= (obstacles[i].y - ypos);
            v5.z -= (obstacles[i].z - zpos);

            /*
        v5.x -= (obstacles[i].x - xpos)/obstacles[i].minDistance*(obstacles[i].minDistance-distance);
             v5.y -= (obstacles[i].y - ypos)/obstacles[i].minDistance*(obstacles[i].minDistance-distance);
             v5.z -= (obstacles[i].z - zpos)/obstacles[i].minDistance*(obstacles[i].minDistance-distance);
             */

         } // end if
      } // end for
   }


   // go for food

   /* needs updating!!!! */
   public void rule6() {
      v6.setXYZ(0,0,0);

      for (int i=0; i < foods.size(); ++i)
      {
         Food currentFood = (Food) foods.get(i);
         float distance = dist(xpos, ypos, zpos, currentFood.x, currentFood.y, currentFood.z);

         //v6.x += (currentFood.x - xpos) / FOOD_PULL_FACTOR * (1.0/MAX_DISTANCE*distance*2);
         //v6.y += (currentFood.y - ypos) / FOOD_PULL_FACTOR * (1.0/MAX_DISTANCE*distance*2);
         v6.x = (currentFood.x - xpos) / FOOD_PULL_FACTOR;
         v6.y = (currentFood.y - ypos) / FOOD_PULL_FACTOR;
         v6.z = (currentFood.z - zpos) / FOOD_PULL_FACTOR;

         if (distance < currentFood.minDistance)
         {
            currentFood.filling--;
            currentFood.vx += vx/50;
            currentFood.vy += vy/50;
            currentFood.vz += vz/50;
         } // end if
      } // end for
   }

} // end class Boid


/**
* Stores all the custom flocking and grouping behaviour
* for boids.
*
*
*/ 
public class Flock 
{

   public Flock() {

   } 


}

class Food extends Obstacle{

  public int filling;
  float maxSize = 15;
  float currentSize = 15;
  float vx, vy, vz;

  Food(int x, int y, int z) 
  {
    super();
    this.x = x;
    this.y = y;
    this.z = z;
    minDistance = FOOD_DISTANCE;
    filling = 200;
  } 

  public void draw() 
  {

    if (vx > 0) {
      vx *= .9f; 
    }
    if (vy > 0) {
      vy *= .9f; 
    }
    if (vz > 0) {
      vz *= .9f; 
    }

    if (x + vx < 0 || x + vx > _world.x)
      vx = -vx*BOUNCE_ABSORPTION;
    if (y + vy < 0 || y + vy > _world.y)
      vy = -vy*BOUNCE_ABSORPTION;
    if (z + vz < 0 || z + vz > _world.z)
      vz = -vz*BOUNCE_ABSORPTION;

    x += vx;
    y += vy;
    z  += vz;

    //strokeWeight(3);
    //stroke(0);
    noStroke();
    fill(0,200,0);
    currentSize = maxSize/200.0f*filling;
    pushMatrix();
    translate(x,y,z);
    box(currentSize);
    //ellipse(x, y, currentSize,currentSize); 
    popMatrix();
    if (filling <= 0) {
      foods.remove(this); 
    }
  }

}


public interface IRenderer
{
   public void render(IRenderable entity);
}


public interface IRenderable
{
   public void setRenderer(IRenderer renderer);
}


class Obstacle {

  public int x, y, z, mySize, minDistance;

  Obstacle() {
    x = PApplet.parseInt(random(_world.x));
    //y = 0;
    y = PApplet.parseInt(random(_world.y));
    z = PApplet.parseInt(random(_world.z));
   mySize = PApplet.parseInt(random(10, 20));
    minDistance = mySize + OBSTACLE_DISTANCE;
  } 

  public void draw() {
    strokeWeight(3);
   // stroke(0);
    noStroke();
    fill(50,50,100,150);
    pushMatrix();
    //translate(0,0,z);
    //ellipse(x, y, 10,10); 
    translate(x,y,z);
    box(mySize); 
    popMatrix();
  }

}

class Predator extends Obstacle {
  float vx = 0;
  float vy = 0;
  float vz = 0;

  Predator() {
    super();
    while(vx==0 || vy ==0 || vz ==0) {
      vx = PApplet.parseInt(random(-1.1f, 1.1f));
      vy = PApplet.parseInt(random(-1.1f, 1.1f));
      vz = PApplet.parseInt(random(-1.1f, 1.1f));
    }
    minDistance = PREDATOR_DISTANCE;

  }
  public void draw() {
    if (x+vx > _world.x || x+vx < 0) {
      vx*=-1;
    } 
    if (y+vy > _world.y || y+vy<0) {
      vy*=-1; 
    }
    
    if (z+vz> _world.z || z+vz <0) {
     vz*=-1; 
    }
    x += vx;
    y += vy;
    z += vz;

    // super.draw();

    //strokeWeight(1.5);
    noStroke();
    fill(255,0,0,100);
    pushMatrix();
    translate(x,y,z);
    box(9); 
    popMatrix();
  }
}



/********************************************************************************************
 * BOIDS
 *******************************************************************************************/



public class BoidRenderer implements IRenderer
{
   public void render(IRenderable entity)
   {
      Boid boid = (Boid)entity;
      int _blue = ((int)(boid.xpos/1500))*255-100;
      //colorMode(HSB);
      /*
      if (frameCount % 5 == 0)
       {
       strokeWeight(random(2,.5));
       stroke(0);
       }
       else
       {
       noStroke();
       }
       */
      scale(noise(1,1,2002)*1-(random(2.5f,.1f)));
      for (int cubes = 1; cubes < 4; cubes ++)
      {  
         //scale(random(1,1.1));
         //rotate(radians(noise(10,70)*110)); 

         colorMode(RGB);
         //fill(cubes*20,255, 200,255 - (cubes * 63.75));

         // light light grey renderer (best on white backgrounds).
         colorMode(HSB);
         //fill(noise(frameRate* 200),(noise(frameCount)*2)+10);
         fill(cubes*noise(boid.xpos),80 + (cubes * 0.75f));
         box(boid.mySize/2 * (cubes * 2.35f));
         //box(int((boid.xpos+boid.ypos+boid.zpos)/3500 + cubes*1.1));
         //sphere(boid.mySize * (cubes * 2.35));
      }
      colorMode(RGB);
      //scale(1);
   }
}


public class NetworkBoidRenderer implements IRenderer
{
   public void render(IRenderable entity)
   {
      Boid boid = (Boid)entity;

      scale(noise(1,1,2002)*1-(random(2.5f,.1f)));
      for (int cubes = 1; cubes < 4; cubes ++)
      {  
         //scale(random(1,1.1));
         //rotate(radians(noise(10,70)*110)); 

         colorMode(RGB);
         fill(cubes*random(40,50),255 - (cubes * 63.75f));

         /* light light grey renderer (best on white backgrounds).
          colorMode(HSB);
          fill(noise(frameRate* 200),(noise(frameCount)*2)+10);
          */
         box(boid.mySize * (cubes * 2.35f));
      }
      colorMode(RGB);
      //scale(1);
   }
}

public class BoidGreyRenderer implements IRenderer
{
   public void render(IRenderable entity)
   {
      Boid boid = (Boid)entity;
      int _blue = ((int)(boid.xpos/1500))*255-100;
      colorMode(HSB);
      /*
      if (frameCount % 5 == 0)
       {
       strokeWeight(random(2,.5));
       stroke(0);
       }
       else
       {
       noStroke();
       }
       */
      scale(noise(1,1,2002)*1-(random(2,.1f)));
      for (int cubes = 1; cubes < 5; cubes ++)
      {  
         //scale(random(1,1.1));
         //rotate(radians(noise(10,70)*110)); 
         //fill(cubes*20,255, 100,255 - (cubes * 63.75));

         // light light grey renderer (best on white backgrounds).
         fill(noise(frameRate)* noise(10,50),(noise(frameCount)*2)+5);
         box(boid.mySize * (cubes * 2.35f));
        // boid.mySize = boid.mySize * (int)(cubes * 2.35);
      }
      colorMode(RGB);
      //scale(1);
   }

}

public class BoidImageRenderer implements IRenderer
{

   
   public void render(IRenderable entity)
   {
      Boid boid = (Boid)entity;
   }
}








/********************************************************************************************
 * BACKGROUND
 *******************************************************************************************/




public class BackgroundRenderer implements IRenderer
{
   public void render(IRenderable entity)
   {
   }
}

public class SaturatedBackgroundRenderer extends BackgroundRenderer implements IRenderer
{
   public void render(IRenderable entity)
   {
      // 3 nices lines with the light grey boid renderer.
      // Very saturated background that makes the light objects like clouds.     
      colorMode(HSB);
      background((abs(flock[0].xpos)/1500)*255,255,100);
      colorMode(RGB);      
   }
}


public class NoiseGreyScaleBackgroundRenderer implements IRenderer
{
   public void render(IRenderable entity)
   {
      //colorMode(RGB);

      background((noise(flock[0].xpos)*255)+180);
      //noiseDetail(1, .90);
      //background(255- (noise(frameCount,10)*50));
      
      //background(255,10,10);

      //colorMode(HSB); 
      

   }
}


/********************************************************************************************
 * WORLD
 *******************************************************************************************/



public class WorldRenderer implements IRenderer
{
   public void render(IRenderable entity)
   {
      World world = (World)entity;
      renderCube();

   }

   private void renderCube()
   {
      //translate(-_world.x/2,-_world.y/2,-_world.z/2); //DONE
      
      // to be outside of the cube..
      //translate( -_world.x/2, -_world.y/2, -_world.z/2 );
      
      translate(0,0,0);
      
      stroke(200,10);
      strokeWeight(10);

      line(0,0,0,0,0,_world.z);
      line(_world.x, 0, 0, _world.x, 0, _world.z);
      line(_world.x, _world.y, 0, _world.x, _world.y, _world.z);
      line(0, _world.y, 0, 0, _world.y, _world.z);

      line(0,0,0, _world.x, 0,0);
      line(0, _world.y, 0, _world.x, _world.y, 0);
      line(0,0,_world.z, _world.x, 0,_world.z);
      line(0, _world.y, _world.z, _world.x, _world.y, _world.z);

      line(0,0,0, 0, _world.y, 0);
      line(_world.x,0,0, _world.x, _world.y,0); 
      line(0,0, _world.z,  0, _world.y,  _world.z);
      line(_world.x,0, _world.z, _world.x, _world.y, _world.z); 
   }
   
}








/**
 * Datentyp, um einen 2D-Vektor zu speichern.
 * plus einige n\u0178tzliche Vektor-Rechen funktionen.
 * @author Patrick Meister
 *
 */

public class Vector {

  public float x, y;

  public Vector(float _x, float _y) {
    x = _x;
    y = _y;
  } 
  
  public Vector() {
   x = 0;
   y = 0; 
  }

  public Vector copy() {
    return new Vector(x, y); 
  }

  public float length() {
    return sqrt(x*x + y*y);
  }
  
  public void setXY(float x, float y) {
   this.x = x;
  this.y = y; 
  }
  
  public Vector normalize() {
    return divide(length());
  }

  public Vector divide(float _divisor) {
    return new Vector(x/_divisor, y/_divisor);
  }

  // todo: winkel dieses vektors zur\u0178ckgeben
  public float direction() {
    return 0.0f;
  }
  
  // gibt einen vektor zur\u0178ck, der die selbe richtung, aber die angegebene l\u0160nge hat.
  public Vector sameDirWithLength(float _length) {
    return normalize().multiply(_length);
  
  }

  
  public Vector multiply(float _multiplier) {
    return new Vector(x * _multiplier, y * _multiplier);
  }

  public Vector multiply(Vector _multiplier) {
    return new Vector(x * _multiplier.x, y * _multiplier.y);
  }

  public Vector subtract(Vector _subtraction) {
    return new Vector(x - _subtraction.x, y - _subtraction.y); 
  }

  public Vector subtract(float _subX, float _subY) {
    return new Vector(x - _subX, y - _subY); 
  }

  public Vector add(Vector _addition) {
    return new Vector(x + _addition.x, y + _addition.y);  
  }
  
  public Vector add(float x, float y) {
    return new Vector(x+ this.x, y + this.y);  
  }
}

/////////////////////////
////
//     QUICK & DIRTY!!!!!!
///
/////////////////////////


/**
 * Datentyp, um einen 2D-Vektor zu speichern.
 * plus einige n\u0178tzliche Vektor-Rechen funktionen.
 * @author Patrick Meister
 *
 */

public class Vector3 {

  public float x, y, z;

  public Vector3(float _x, float _y, float _z) {
    x = _x;
    y = _y;
    z = _z;
  } 

  public Vector3() {
    x = 0;
    y = 0; 
    z = 0;
  }

  public Vector3 copy() {
    return new Vector3(x, y, z); 
  }


  public float length() {
    return sqrt(x*x + y*y +z*z);
  }


  public void setXYZ(float x, float y, float z) 
  {
    this.x = x;
    this.y = y; 
    this.z = z;
  }
  /*
  public Vector3 normalize() {
   return divide(length());
   }
   
   public Vector3 divide(float _divisor) {
   return new Vector3(x/_divisor, y/_divisor);
   }
   
   // todo: winkel dieses vektors zur\u0178ckgeben
   public float direction() {
   return 0.0;
   }
   
   // gibt einen vektor zur\u0178ck, der die selbe richtung, aber die angegebene l\u0160nge hat.
   public Vector3 sameDirWithLength(float _length) {
   return normalize().multiply(_length);
   
   }
   
   
   public Vector3 multiply(float _multiplier) {
   return new Vector3(x * _multiplier, y * _multiplier);
   }
   
   public Vector3 multiply(Vector3 _multiplier) {
   return new Vector3(x * _multiplier.x, y * _multiplier.y);
   }
   
   public Vector3 subtract(Vector3 _subtraction) {
   return new Vector3(x - _subtraction.x, y - _subtraction.y); 
   }
   
   public Vector3 subtract(float _subX, float _subY) {
   return new Vector3(x - _subX, y - _subY); 
   }
   
   public Vector3 add(Vector3 _addition) {
   return new Vector3(x + _addition.x, y + _addition.y);  
   }
   
   public Vector3 add(float x, float y) {
   return new Vector3(x+ this.x, y + this.y);  
   }
   */
}




public class World extends Vector3 implements IRenderable
{
   IRenderer _renderer;
   
   public World(float _x, float _y, float _z) 
   {
      super(_x, _y, _z);
  } 

  public World() 
  {
     super();
  }
  
  public void setRenderer(IRenderer renderer)
  {
     _renderer = renderer;
  }
  
  public void render()
  {
     _renderer.render( this );
  }
  
  
}
  static public void main(String args[]) {     PApplet.main(new String[] { "BoidCamArty_Object_00" });  }}